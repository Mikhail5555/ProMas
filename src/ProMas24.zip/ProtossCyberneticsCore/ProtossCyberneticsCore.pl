:-dynamic 
	self/2,			% our own ID from the self/5 percept
	upgrade/2, 		% This upgrade is done
	upgrading/1.		% Is there anything being researched 