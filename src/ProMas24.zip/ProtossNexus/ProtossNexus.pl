:-dynamic 
	self/2,			% our own ID from the self/5 percept
	queueSize/1,		% The queueSize of the building
	friendly/3.		% All friendly units
